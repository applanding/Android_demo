package com.demo.retrodemo.utils.api;

public class ApiUtils {
    public static final String BASE_URL = "http://jsonplaceholder.typicode.com/";

    public static APIService getAPIService() {
        return APIService.RetrofitClient.getClient(BASE_URL).create(APIService.class);
    }
}
