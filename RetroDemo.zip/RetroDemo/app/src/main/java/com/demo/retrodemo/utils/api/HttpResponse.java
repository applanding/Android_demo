package com.demo.retrodemo.utils.api;

/**
 * Created by khushi on 6/12/16.
 */

public class HttpResponse {
    String httpResponseMessage = "";
    int httpResponseCode = 0;

    public String getHttpResponseMessage() {
        return httpResponseMessage;
    }

    public void setHttpResponseMessage(String httpResponseMessage) {
        this.httpResponseMessage = httpResponseMessage;
    }

    public int getHttpResponseCode() {
        return httpResponseCode;
    }

    public void setHttpResponseCode(int httpResponseCode) {
        this.httpResponseCode = httpResponseCode;
    }
}
