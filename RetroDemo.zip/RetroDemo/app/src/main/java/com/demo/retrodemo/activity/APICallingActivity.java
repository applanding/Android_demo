package com.demo.retrodemo.activity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.demo.retrodemo.R;
import com.demo.retrodemo.models.ResponseDemo;
import com.demo.retrodemo.utils.api.APIService;
import com.demo.retrodemo.utils.api.ApiUtils;
import com.demo.retrodemo.utils.api.HttpResponse;
import com.demo.retrodemo.utils.api.HttpServiceHandler;
import com.demo.retrodemo.utils.other.Helper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class APICallingActivity extends AppCompatActivity {
    private static final String TAG = "RetroDemo MainActivity";
    private TextView mResponseTv;
    private APIService mAPIService;
    Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_api_calling);
        final EditText titleEt = findViewById(R.id.et_title);
        final EditText bodyEt = findViewById(R.id.et_body);
        Button submitBtn = findViewById(R.id.btn_submit);
        mResponseTv = findViewById(R.id.tv_response);

        mAPIService = ApiUtils.getAPIService();
        gson = new GsonBuilder().setPrettyPrinting().create();

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = titleEt.getText().toString().trim();
                String body = bodyEt.getText().toString().trim();
                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(body)) {
//                    sendPost(title, body);
                    if (Helper.isNetworkAvailable(APICallingActivity.this)) {
                        new SendPost(title,body).executeOnExecutor(AsyncTask
                                .THREAD_POOL_EXECUTOR);
                    }
//                    else {
//                        snackbar = Snackbar
//                                .make(mRelativeLayoutLogin, getString(R.string.internet_not_available),
//                                        Snackbar.LENGTH_LONG);
//                        snackbar.show();
//                        Helper.hideSoftKeyboard(this);
//                    }
                }
            }
        });

    }

    private class SendPost extends AsyncTask<Void, Void, HttpResponse> {

        String title;
        String body;

        HttpResponse response;
        ProgressDialog mProgressDialog;

        SendPost(String title, String body) {
            this.title = title;
            this.body = body;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.d(TAG, "SendMPIN:" + "onPreExecute()");
            mProgressDialog = new ProgressDialog(APICallingActivity.this);
//            mProgressDialog.setMessage(getString(R.string.please_wait_));
            mProgressDialog.setCancelable(false);
            mProgressDialog.show();
        }

        @Override
        protected HttpResponse doInBackground(Void... params) {
            Log.d(TAG, "SendMPIN:" + "doInBackground()");
            JSONObject json = new JSONObject();
            try {
                json.put("title", title);
                json.put("body", body);
                json.put("userId", 1);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            response = new HttpServiceHandler().makeHttpRequestWithJson(APICallingActivity.this,
                    "http://jsonplaceholder.typicode.com/posts", json.toString());
            return response;
        }

        @Override
        protected void onPostExecute(HttpResponse httpResponse) {
            super.onPostExecute(httpResponse);
            try {
                Log.d(TAG, "SendMPIN:" + "onPostExecute()");
                if (mProgressDialog != null && mProgressDialog.isShowing())
                    mProgressDialog.dismiss();
                if (httpResponse != null) {
                    if (httpResponse.getHttpResponseCode() >= 200 && httpResponse
                            .getHttpResponseCode() <= 299) {
                        if (!TextUtils.isEmpty(httpResponse.getHttpResponseMessage())) {

                        } else {

                        }
                    }
                    if (httpResponse.getHttpResponseCode() >= 400 && httpResponse
                            .getHttpResponseCode() <= 599) {

                    }
                } else {

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void sendPost(String title, String body) {
        mAPIService.savePost(title, body, 1).enqueue(new Callback<ResponseDemo>() {
            @Override
            public void onResponse(Call<ResponseDemo> call, Response<ResponseDemo> response) {

                if (response.isSuccessful()) {
                    ResponseDemo responseDemo = response.body();
//                    showResponse(response.body().toString());
//                    startActivity(new Intent(APICallingActivity.this, LoginActivity.class));
                    Log.i(TAG, "post submitted to API." + response.body().toString());
                }
            }

            @Override
            public void onFailure(Call<ResponseDemo> call, Throwable t) {
                Log.e(TAG, "Unable to submit post to API.");
            }
        });
    }


}
