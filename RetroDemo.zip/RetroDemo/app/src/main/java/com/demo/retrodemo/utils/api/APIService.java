package com.demo.retrodemo.utils.api;

import com.demo.retrodemo.models.RequestDemo;
import com.demo.retrodemo.models.ResponseDemo;

import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {


    @POST("/posts")
    @FormUrlEncoded
    Call<ResponseDemo> savePost(@Field("title") String title,
                                @Field("body") String body,
                                @Field("userId") long userId);
    //example
    @Headers({"Header1: header"})
    @GET("users")
    Call<List<RequestDemo>> getUsers();

    class RetrofitClient {

        private static Retrofit retrofit = null;

        public static Retrofit getClient(String baseUrl) {
            if (retrofit==null) {
                HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
// set your desired log level
                logging.setLevel(HttpLoggingInterceptor.Level.BODY);

                OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
// add your other interceptors …

// add logging as last interceptor
                httpClient.addInterceptor(logging);  // <-- this is the important line!
                retrofit = new Retrofit.Builder()
                        .baseUrl(baseUrl)
                        .client(httpClient.build())
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
            }
            return retrofit;
        }
    }
}
