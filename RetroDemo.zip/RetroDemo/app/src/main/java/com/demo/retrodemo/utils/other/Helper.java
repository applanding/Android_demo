package com.demo.retrodemo.utils.other;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

/**
 * Created by khushi on 30/8/16.
 */
public class Helper {

    private static final String TAG = "DMT Helper";

    public static boolean isNetworkAvailable(final Context context) {
        Log.d(TAG, "isNetworkAvailable()");
        if (context != null) {
            final ConnectivityManager connectivityManager = ((ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE));
            return connectivityManager.getActiveNetworkInfo() != null && connectivityManager
                    .getActiveNetworkInfo().isConnected();
        } else
            return false;
    }

    /**
     * Hides the soft keyboard
     */
    public static void hideSoftKeyboard(Activity activity) {
        Log.d(TAG, "hideSoftKeyboard()");
        if (activity.getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) activity
                    .getSystemService(activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken
                    (), 0);
        }
    }

    public static boolean isValidEmail(String email) {
        Log.d(TAG, "isValidEmail()");
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();

    }

    public static String byteArrayToHex(byte[] a) {
        StringBuilder sb = new StringBuilder(a.length * 2);
        for (byte b : a)
            sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }

    public static String getAppVersionName(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context
                    .getPackageName(), 0);
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            // should never happen
            throw new RuntimeException("Could not get package name: " + e);
        }
    }
//
//    public static String getApplicationBuildDate(Context context)
//    {
//        return getDate("MMM dd yyyy", BuildConfig.TIMESTAMP);
//    }
//    private static String getDate(final String dateFormat, final long currenttimemillis)
//    {
//        return new SimpleDateFormat(dateFormat, Locale.ENGLISH).format(currenttimemillis);
//    }
//    public static String getDeviceTypeString(Context context) {
//        PackageManager pm = context.getPackageManager();
//        PackageInfo pi = null;
//        StringBuffer versionString = new StringBuffer();
//        versionString.append(Constants.DEVICE_TYPE).append("__");
//        versionString.append(Build.VERSION.RELEASE).append("__");
//        versionString.append(Build.MANUFACTURER).append("_").append(Build.BRAND).append("_").append(Build.MODEL).append("_").append(Build.DEVICE).append("__");
//        try {
//            pi = pm.getPackageInfo(context.getPackageName(), 0);
//            versionString.append(pi.versionName).append("_").append(pi.versionCode).append("__").
//                    append(context.getResources().getString(R.string.applicationId));
//        } catch (PackageManager.NameNotFoundException e) {
//            e.printStackTrace();
//            versionString.append("unknown").append("__");
//        }
//
//        return versionString.toString();
//    }

//    public void replaceFragment(Fragment frag, Bundle bundle, FragmentActivity activity) {
//        Log.d(TAG, "replaceFragment()");
//        FragmentManager manager = activity.getSupportFragmentManager();
//        if (manager != null) {
//            FragmentTransaction t = manager.beginTransaction();
//            Fragment currentFrag = manager.findFragmentById(R.id.framelayout_container);
//            if (bundle != null)
//                frag.setArguments(bundle);
//
//            // Check if the new Fragment is the same
//            // If it is, don't add to the back stack
//            if (currentFrag != null && currentFrag.getClass().equals(frag.getClass())) {
////                t.replace(R.id.framelayout_container, frag).commit();
//            } else {
//                t.replace(R.id.framelayout_container, frag).addToBackStack(null).commit();
//            }
//        }
//    }
//
//    public String generateMD5(String s) {
//        try {
//            MessageDigest digest = MessageDigest.getInstance("MD5");
//            digest.update(s.getBytes());
//            byte messageDigest[] = digest.digest();
//            Log.d(TAG, "MD5 of " + s + ":" + new String(Hex.encodeHex(messageDigest)));
//            return new String(Hex.encodeHex(messageDigest));
//
//        } catch (NoSuchAlgorithmException e) {
//            e.printStackTrace();
//        }
//        return "";
//    }

//    public String generateMPINString(String mPin, String amount) {
//        SimpleDateFormat format = new SimpleDateFormat("dd");
//        String cdate = format.format(Calendar.getInstance().getTime());
//        Log.d(TAG, "Mpin:" + mPin + "Amount:" + amount + "Date:" + cdate);
//        return generateMD5(generateMD5(mPin) + Constants.MPIN_STATIC_STRING + amount + cdate);
//    }

    //Remitter, Beneficiary, Transaction Creation, Requery transaction, Delete Beneficiary,
    // Verify Remitter, Verify Beneficiary
//    public static boolean isServiceAvailable(Snackbar snackbar, View snackView, Context context) {
//        if (Constants.REMOTE_CONFIG_IS_SERVICE_AVAILABLE) {
//            return true;
//        } else {
//            snackbar = Snackbar.make(snackView, context.getString(R.string.service_unavailable),
//                    Constants.SNACKBAR_LENGTH);
//            snackbar.show();
//            return false;
//        }
//    }
//
//    public static void initialiseDatabase(Context context) {
//        if (Constants.dataBaseHelper == null)
//            Constants.dataBaseHelper = new DataBaseHelper(context);
//    }
}
