package com.demo.retrodemo.utils.api;

import android.content.Context;
import android.net.Uri;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

public class HttpServiceHandler {
    public static final String TAG = "HttpServiceHandler";

    private int timeOut = 5*60*1000; // 5min

    public HttpResponse makeHttpRequest(Context context, Uri urlString) {
        StringBuffer buffer = new StringBuffer("");
        HttpResponse response = null;
        HttpURLConnection connection = null;
        try {
            Log.d(TAG, "makeHttpRequest");
            Log.d(TAG, "URL:" + urlString);
            URL url = new URL(urlString.toString());
            System.setProperty("http.keepAlive", "false");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setDoOutput(false);
            connection.setConnectTimeout(timeOut);
            connection.setReadTimeout(timeOut);
            connection.setChunkedStreamingMode(0);
            connection.setRequestProperty("Connection", "close");
            connection.connect();
            Log.d(TAG, "Response code:" + connection.getResponseCode() + " method:" + connection
                    .getRequestMethod());
            Log.d(TAG, "Response message:" + connection.getResponseMessage());
            response = new HttpResponse();
            InputStream inputStream = null;
            InputStream error = null;
            try {
                // SUCCESS response
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() <= 299) {
                    inputStream = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                    String line = "";
                    while ((line = rd.readLine()) != null)
                        buffer.append(line);
                    response.setHttpResponseMessage(buffer.toString());
                    response.setHttpResponseCode(connection.getResponseCode());
                    if (inputStream != null)
                        inputStream.close();
                }
                // FAILURE response
                else if (connection.getResponseCode() >= 400 && connection.getResponseCode() <=
                        599) {
                    error = connection.getErrorStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(error));
                    String line = "";
                    while ((line = rd.readLine()) != null)
                        buffer.append(line);
                    response.setHttpResponseMessage(buffer.toString());
                    response.setHttpResponseCode(connection.getResponseCode());
                    if (error != null)
                        error.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
//                Toast.makeText(context, context.getString(R.string.try_again_later), Toast
//                        .LENGTH_LONG).show();
                if (error != null)
                    error.close();
                if (inputStream != null)
                    inputStream.close();
                if (connection != null)
                    connection.disconnect();
            }

            Log.d(TAG, "Response:" + response.getHttpResponseMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null)
                connection.disconnect();
        }
        return response;
    }

    private String getDataAsString(HashMap<String, String> params) throws
            UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

    public HttpResponse loginHttpRequestWithJson(Context context, String urlString, String json) {
        StringBuffer buffer = new StringBuffer("");
        HttpResponse response = null;
        HttpURLConnection connection = null;
        try {
            Log.d(TAG, "loginHttpRequestWithJson");
            Log.d(TAG, "URL:" + urlString);
            URL url = new URL(urlString);
            System.setProperty("http.keepAlive", "false");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setReadTimeout(timeOut);
            connection.setConnectTimeout(timeOut);
            connection.setChunkedStreamingMode(0);
            connection.setRequestProperty("Connection", "close");
            OutputStream os = connection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            if (json != null) {
                Log.d(TAG, "Data:" + json);
                writer.write(json);
            }
            writer.flush();
            writer.close();
            os.close();

            connection.connect();
            Log.d(TAG, "Response code:" + connection.getResponseCode());
            Log.d(TAG, "Response message:" + connection.getResponseMessage());
            response = new HttpResponse();
            InputStream inputStream = null;
            InputStream error = null;
            try {
                // SUCCESS response
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() <= 299) {
                    inputStream = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                    String line = "";
                    while ((line = rd.readLine()) != null)
                        buffer.append(line);
                    response.setHttpResponseMessage(buffer.toString());
                    response.setHttpResponseCode(connection.getResponseCode());
                    if (inputStream != null)
                        inputStream.close();
                }
                // FAILURE response
                else if (connection.getResponseCode() >= 400 && connection.getResponseCode() <=
                        599) {
                    error = connection.getErrorStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(error));
                    String line = "";
                    while ((line = rd.readLine()) != null)
                        buffer.append(line);
                    response.setHttpResponseMessage(buffer.toString());
                    response.setHttpResponseCode(connection.getResponseCode());
                    if (error != null)
                        error.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
//                Toast.makeText(context, context.getString(R.string.try_again_later), Toast
//                        .LENGTH_LONG).show();
                if (error != null)
                    error.close();
                if (inputStream != null)
                    inputStream.close();
                if (connection != null)
                    connection.disconnect();
            }

            Log.d(TAG, "Response:" + response.getHttpResponseMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null)
                connection.disconnect();
        }
        return response;
    }

    public HttpResponse makeHttpRequestWithJson(Context context, String urlString, String json) {
       StringBuffer buffer = new StringBuffer("");
        HttpResponse response = null;
        HttpURLConnection connection = null;
        try {
            Log.d(TAG, "makeHttpRequestWithJson");
            Log.d(TAG, "URL:" + urlString);
            URL url = new URL(urlString);
            System.setProperty("http.keepAlive", "false");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setReadTimeout(timeOut);
            connection.setConnectTimeout(timeOut);
            connection.setChunkedStreamingMode(0);
            connection.setRequestProperty("Connection", "close");

            OutputStream os = connection.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
            if (json != null) {
                Log.d(TAG, "Data:" + json);
                writer.write(json);
            }
            writer.flush();
            writer.close();
            os.close();

            connection.connect();
            Log.d(TAG, "Response code:" + connection.getResponseCode());
            Log.d(TAG, "Response message:" + connection.getResponseMessage());
            response = new HttpResponse();
            InputStream inputStream = null;
            InputStream error = null;
            try {
                // SUCCESS response
                if (connection.getResponseCode() >= 200 && connection.getResponseCode() <= 299) {
                    inputStream = connection.getInputStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream));
                    String line = "";
                    while ((line = rd.readLine()) != null)
                        buffer.append(line);
                    response.setHttpResponseMessage(buffer.toString());
                    response.setHttpResponseCode(connection.getResponseCode());
                    if (inputStream != null)
                        inputStream.close();
                }
                // FAILURE response
                else if (connection.getResponseCode() >= 400 && connection.getResponseCode() <=
                        599) {
                    error = connection.getErrorStream();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(error));
                    String line = "";
                    while ((line = rd.readLine()) != null)
                        buffer.append(line);
                    response.setHttpResponseMessage(buffer.toString());
                    response.setHttpResponseCode(connection.getResponseCode());
                    if (error != null)
                        error.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
//                Toast.makeText(context, context.getString(R.string.try_again_later), Toast
//                        .LENGTH_LONG).show();
                if (error != null)
                    error.close();
                if (inputStream != null)
                    inputStream.close();
                if (connection != null)
                    connection.disconnect();
            }

            Log.d(TAG, "Response:" + response.getHttpResponseMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null)
                connection.disconnect();
        }
        return response;
    }

}
